<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "meditrust_db";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>' OR '1'='1